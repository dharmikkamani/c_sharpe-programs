﻿
namespace Marks
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.Label();
            this.division = new System.Windows.Forms.Label();
            this.sem = new System.Windows.Forms.Label();
            this.strean = new System.Windows.Forms.Label();
            this.ss = new System.Windows.Forms.Label();
            this.sid = new System.Windows.Forms.TextBox();
            this.sname = new System.Windows.Forms.TextBox();
            this.saddress = new System.Windows.Forms.TextBox();
            this.sdivision = new System.Windows.Forms.TextBox();
            this.ssem = new System.Windows.Forms.TextBox();
            this.city = new System.Windows.Forms.TextBox();
            this.stream = new System.Windows.Forms.ComboBox();
            this.submit = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.addmarks = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(261, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Details";
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.Location = new System.Drawing.Point(88, 106);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(24, 20);
            this.id.TabIndex = 1;
            this.id.Text = "Id";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(88, 152);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(57, 20);
            this.name.TabIndex = 2;
            this.name.Text = "Name";
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Location = new System.Drawing.Point(88, 201);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(78, 20);
            this.address.TabIndex = 3;
            this.address.Text = "Address";
            // 
            // division
            // 
            this.division.AutoSize = true;
            this.division.Location = new System.Drawing.Point(88, 247);
            this.division.Name = "division";
            this.division.Size = new System.Drawing.Size(57, 20);
            this.division.TabIndex = 4;
            this.division.Text = "Class";
            this.division.Click += new System.EventHandler(this.label5_Click);
            // 
            // sem
            // 
            this.sem.AutoSize = true;
            this.sem.Location = new System.Drawing.Point(88, 297);
            this.sem.Name = "sem";
            this.sem.Size = new System.Drawing.Size(46, 20);
            this.sem.TabIndex = 5;
            this.sem.Text = "Sem";
            // 
            // strean
            // 
            this.strean.AutoSize = true;
            this.strean.Location = new System.Drawing.Point(88, 348);
            this.strean.Name = "strean";
            this.strean.Size = new System.Drawing.Size(69, 20);
            this.strean.TabIndex = 6;
            this.strean.Text = "Stream";
            // 
            // ss
            // 
            this.ss.AutoSize = true;
            this.ss.Location = new System.Drawing.Point(88, 393);
            this.ss.Name = "ss";
            this.ss.Size = new System.Drawing.Size(42, 20);
            this.ss.TabIndex = 7;
            this.ss.Text = "City";
            // 
            // sid
            // 
            this.sid.Location = new System.Drawing.Point(215, 103);
            this.sid.Name = "sid";
            this.sid.Size = new System.Drawing.Size(342, 27);
            this.sid.TabIndex = 8;
            // 
            // sname
            // 
            this.sname.Location = new System.Drawing.Point(215, 152);
            this.sname.Name = "sname";
            this.sname.Size = new System.Drawing.Size(342, 27);
            this.sname.TabIndex = 9;
            // 
            // saddress
            // 
            this.saddress.Location = new System.Drawing.Point(215, 201);
            this.saddress.Name = "saddress";
            this.saddress.Size = new System.Drawing.Size(342, 27);
            this.saddress.TabIndex = 10;
            // 
            // sdivision
            // 
            this.sdivision.Location = new System.Drawing.Point(215, 247);
            this.sdivision.Name = "sdivision";
            this.sdivision.Size = new System.Drawing.Size(342, 27);
            this.sdivision.TabIndex = 11;
            // 
            // ssem
            // 
            this.ssem.Location = new System.Drawing.Point(215, 290);
            this.ssem.Name = "ssem";
            this.ssem.Size = new System.Drawing.Size(342, 27);
            this.ssem.TabIndex = 12;
            // 
            // city
            // 
            this.city.Location = new System.Drawing.Point(215, 390);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(342, 27);
            this.city.TabIndex = 13;
            // 
            // stream
            // 
            this.stream.FormattingEnabled = true;
            this.stream.Items.AddRange(new object[] {
            "BCA ",
            "BSC IT"});
            this.stream.Location = new System.Drawing.Point(215, 345);
            this.stream.Name = "stream";
            this.stream.Size = new System.Drawing.Size(342, 28);
            this.stream.TabIndex = 14;
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(92, 457);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(85, 25);
            this.submit.TabIndex = 15;
            this.submit.Text = "Submit";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(475, 457);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(82, 27);
            this.clear.TabIndex = 16;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // addmarks
            // 
            this.addmarks.Location = new System.Drawing.Point(297, 457);
            this.addmarks.Name = "addmarks";
            this.addmarks.Size = new System.Drawing.Size(105, 27);
            this.addmarks.TabIndex = 17;
            this.addmarks.Text = "Addmarks";
            this.addmarks.UseVisualStyleBackColor = true;
            this.addmarks.Click += new System.EventHandler(this.addmarks_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 550);
            this.Controls.Add(this.addmarks);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.stream);
            this.Controls.Add(this.city);
            this.Controls.Add(this.ssem);
            this.Controls.Add(this.sdivision);
            this.Controls.Add(this.saddress);
            this.Controls.Add(this.sname);
            this.Controls.Add(this.sid);
            this.Controls.Add(this.ss);
            this.Controls.Add(this.strean);
            this.Controls.Add(this.sem);
            this.Controls.Add(this.division);
            this.Controls.Add(this.address);
            this.Controls.Add(this.name);
            this.Controls.Add(this.id);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label id;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.Label division;
        private System.Windows.Forms.Label sem;
        private System.Windows.Forms.Label strean;
        private System.Windows.Forms.Label ss;
        private System.Windows.Forms.TextBox sname;
        private System.Windows.Forms.TextBox saddress;
        private System.Windows.Forms.TextBox sdivision;
        private System.Windows.Forms.TextBox ssem;
        private System.Windows.Forms.TextBox city;
        private System.Windows.Forms.ComboBox stream;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.TextBox sid;
        private System.Windows.Forms.Button addmarks;
    }
}

