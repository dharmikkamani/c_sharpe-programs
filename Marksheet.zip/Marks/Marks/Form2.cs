﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Marks
{
    public partial class Form2 : Form
    {
        int tot;
        int perc;
        int result;
        string gradef;
        int id;

        public Form2()
        {
            InitializeComponent();
            show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void show()
        {
            string show = "select * from Student";
            SqlDataAdapter da = new SqlDataAdapter(show,Class1.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            
        }



     

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            id = Convert.ToInt32(row.Cells[0].Value.ToString());
            MessageBox.Show(id.ToString(),"You Are Inserting ");
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void submit_Click(object sender, EventArgs e)
        {
            adddata();
        }

        private void adddata()
        {
            string data = "select m1,m2,m3,m4 from Result";
            SqlDataAdapter da = new SqlDataAdapter(data, Class1.con);
            DataTable dt = new DataTable();
            int check = da.Fill(dt);

            if (data != "")
            {
                if (m1.Text != "" && m2.Text != "" && m3.Text != "" && m4.Text != "")
                {
                    tot = Convert.ToInt32(m1.Text) + (Convert.ToInt32(m2.Text)) + (Convert.ToInt32(m3.Text)) + (Convert.ToInt32(m4.Text));
                    perc = Convert.ToInt32(tot) / 4;
                    if (perc >= 80)
                    {
                        result = 1;
                        gradef = "A";
                    }
                    else if (perc >= 70)
                    {
                        result = 1;
                        gradef = "B";
                    }
                    else
                    {
                        MessageBox.Show("Fail");
                    }

                    string ins = "insert into Result values('" + id + "','" + m1.Text + "','" + m2.Text + "','" + m3.Text + "','" + m4.Text + "','" + tot + "','" + perc + "','" + result + "','" + gradef + "')";
                    SqlDataAdapter da1 = new SqlDataAdapter(ins, Class1.con);
                    DataTable dt1 = new DataTable();
                    int a = da1.Fill(dt1);

                    if (a == 0)
                    {
                        MessageBox.Show("Mark Entered", "Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Mark Not Insert");
                    }
                }
                else
                {
                    MessageBox.Show("Record Already Added");
                }
            }
            else
            {
                MessageBox.Show("Record Already Added");
            }

           
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
