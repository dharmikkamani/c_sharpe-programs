﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace VottingSystem
{
  
    public partial class Form1 : Form
    {
        Random rm = new Random();
        int votterid;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            votterid = rm.Next();
            String vid = "SELECT * FROM Votterdata WHERE votid ='" + votterid + "'";
            SqlDataAdapter da1 = new SqlDataAdapter(vid,Class1.con);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);

            if (textBox1.Text != "" && textBox2.Text != "")
            {
                if (dt1.Rows.Count > 0)
                {
                    MessageBox.Show("This Votter Id Is ALready Generated");
                }
                else
                {

                    string ins = "INSERT INTO Votterdata VALUES('" + textBox1.Text + "','" + votterid + "','" + textBox2.Text + "')";
                    SqlDataAdapter da = new SqlDataAdapter(ins, Class1.con);
                    DataTable dt = new DataTable();
                    int a = da.Fill(dt);
                    if (a == 0)
                    {
                        MessageBox.Show("Record Inserted");
                        clear();
                    }
                    else
                    {
                        MessageBox.Show("Something Wrong");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please Fill The Values First","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();
        }
    }
    }

